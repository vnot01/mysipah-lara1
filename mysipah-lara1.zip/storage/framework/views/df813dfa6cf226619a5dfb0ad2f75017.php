<?php $__empty_1 = true; $__currentLoopData = $scanKartu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="form-group" align="center">
    <label>Scan Your RFID Card</label>
    <br>
    <img src="<?php echo e(url('/upload/rfid.gif')); ?>"
        style="height: 100px;width:100px;" >
    <br>
    
    <input disabled type="text" name="nokartu" id="nokartu"
        placeholder="Tempelkan Kartu RFID" class="form-control"
        style="width: 200px;" value='<?php echo e($item->nokartu); ?>'>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\laragon\www\mysipah-lara1\resources\views/nasabah/nokartu.blade.php ENDPATH**/ ?>