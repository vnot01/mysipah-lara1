<?php $__env->startSection('admin'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">
    <div class="row profile-body">
        <!-- left wrapper start -->
        <div class="d-none d-md-block col-md-4 col-xl-4 left-wrapper">
            <div class="card rounded mb-3">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <div class="position-relative">
                            <div>
                                <img class="wd-100 rounded-circle"
                                    src="<?php echo e((!empty($profileData->photo)) ? url('upload/admin_images/'.$profileData->photo) : url('upload/no_image.jpg')); ?>"
                                    alt="profile">
                                <span class="h4 ms-3"><?php echo e($profileData->username); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="mt-3">
                        <label class="tx-11 fw-bolder mb-0 text-uppercase">Name:</label>
                        <p class="text-muted"><?php echo e($profileData->name); ?></p>
                    </div>
                    <div class="mt-3">
                        <label class="tx-11 fw-bolder mb-0 text-uppercase">Email:</label>
                        <p class="text-muted"><?php echo e($profileData->email); ?></p>
                    </div>
                    <div class="mt-3">
                        <label class="tx-11 fw-bolder mb-0 text-uppercase">Phone:</label>
                        <p class="text-muted"><?php echo e($profileData->phone); ?></p>
                    </div>
                    <div class="mt-3">
                        <label class="tx-11 fw-bolder mb-0 text-uppercase">Address:</label>
                        <p class="text-muted"><?php echo e($profileData->address); ?></p>
                    </div>
                    
                
            </div>
        </div>

        <div class="card rounded">
            <div class="card-body">
                <h6 class="card-title">CHANGE PASSWORD</h6>
                <form method="POST" action="<?php echo e(route('admin.change.password')); ?>" class="forms-sample"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="old_password" class="form-label">Old Password</label>
                        <input type="password" class="form-control <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                            id="old_password" name="old_password" autocomplete="off"
                            placeholder="Leave Blank If Not Changes">
                        <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password</label>
                        <input type="password" class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                            id="new_password" name="new_password" autocomplete="off"
                            placeholder="Leave Blank If Not Changes">
                        <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="new_password_confirmation" class="form-label">Confirm New Password</label>
                        <input type="password" class="form-control" id="new_password_confirmation"
                            name="new_password_confirmation" autocomplete="off" placeholder="Confirm Your New Password">
                    </div>
                    <button type="submit" class="btn btn-primary me-2">Update Your Password</button>
                </form>
            </div>
        </div>
    </div>

    <!-- left wrapper end -->
    <!-- middle wrapper start -->
    <div class="col-md-8 col-xl-8 middle-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title">UPDATE PROFILE</h6>
                        <form method="POST" action="<?php echo e(route('admin.profile.store')); ?>" class="forms-sample"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" autocomplete="off"
                                    placeholder="Username" value="<?php echo e($profileData->username); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="name" class="form-label">Name</label>
                                <input type="text" class="form-control" id="name" name="name" autocomplete="on"
                                    placeholder="Name" value="<?php echo e($profileData->name); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="Email"
                                    value="<?php echo e($profileData->email); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone</label>
                                <input type="phone" class="form-control" id="phone" name="phone"
                                    placeholder="Phone Number" value="<?php echo e($profileData->phone); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="address" class="form-label">Address</label>
                                <textarea id="address" name="address" class="form-control"
                                    placeholder="Address"><?php echo e($profileData->address); ?></textarea>
                                
                            </div>
                            <div class="mb-3">
                                <label class="form-label" for="formFile">Photo Upload</label>
                                <div class="row">
                                    <div class="col-sm-2">
                                        <div class="mb-2">
                                            <img id="showImage" class="wd-80 rounded-circle"
                                                src="<?php echo e((!empty($profileData->photo)) ? url('upload/admin_images/'.$profileData->photo) : url('upload/no_image.jpg')); ?>"
                                                alt="profile">
                                        </div>
                                    </div><!-- Col -->
                                    <div class="col-sm-10 align-self-center">
                                        <div class="mb-2">
                                            <input class="form-control" type="file"
                                                accept="image/png,image/jpeg" name="image" id="image">
                                        </div>
                                    </div><!-- Col -->
                                </div><!-- Row -->
                            </div>
                            <button type="submit" class="btn btn-primary me-2">Update Your Changes</button>
                        </form>

                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Token Key (API Key)</h6>
                            <form method="POST" action="<?php echo e(route('admin.profile.membuatToken')); ?>" class="forms-sample"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="token_name" class="form-label">Token Name</label>
                                    <input type="text" class="form-control" id="token_name" name="token_name"
                                        placeholder="Your Token Name" value="<?php echo e($profileData->username.'-token'); ?>">
                                </div>
                                <div class="mb-3">
                                    <button type="submit" class="btn btn-primary me-2">Create New Token</button>
                                </div>
                            </form>
                            
                            <div class="table-responsive">
                                <table id="dataTableExample" class="table">
                                    <thead>
                                        <tr>
                                            <th style="vertical-align : middle;text-align:center;">API TOKENS</th>
                                            <th style="vertical-align : middle;text-align:center;">TYPE</th>
                                            <th style="vertical-align : middle;text-align:center;" colspan="2">ACTION
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $listTokens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <form action="<?php echo e(route('admin.profile.token.hapus', $a->id)); ?>"
                                            method="POST">
                                            
                                            <tr>
                                                <td style="vertical-align : middle;text-align:center;">
                                                    <input type="text" class="form-control" value="<?php echo e($a->api_tokens); ?>"
                                                        id="<?php echo e($a->id); ?>-<?php echo e($a->api_tokens); ?>" name="api_tokens" readonly>
                                                    <input type="hidden" class="form-control" value="<?php echo e($a->id); ?>"
                                                        id="<?php echo e($a->id); ?>-<?php echo e($a->api_tokens); ?>" name="id_token" readonly>
                                                </td>
                                                <td style="vertical-align : middle;text-align:center;">
                                                    <?php echo e($a->token_type); ?>

                                                </td>
                                                <td class="text-center">
                                                    <button type="button" class="btn btn-info btn-icon"
                                                        onclick="CopyToClipboard('<?php echo e($a->id); ?>-<?php echo e($a->api_tokens); ?>')"
                                                        data-bs-toggle="tooltip" data-bs-placement="top"
                                                        title="Copy Token to Clipboard">
                                                        <i data-feather="clipboard"></i>
                                                    </button>
                                                    <button class="btn btn-primary"
                                                    onclick="showSwal('passing-parameter-execute-cancel')">Click
                                                    here!</button>

                                                </td>
                                                <td class="text-center">
                                                    
                                                    
                                                    
                                                    
                                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" onclick="return confirm('Are you sure?')"
                                                        class="btn btn-danger btn-icon" data-bs-toggle="tooltip"
                                                        data-bs-placement="top" title="Delete Token">
                                                        <i data-feather="trash-2"></i>
                                                    </button>
                                                    
                                                </td>
                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <div class="alert alert-danger">
                                                Data Not Available.
                                            </div>
                                            <?php endif; ?>
                                        </form>
                                        
                                    </tbody>
                                </table>
                                <?php echo $listTokens->withQueryString()->links('pagination::bootstrap-5'); ?>

                                
                            </div>
                           
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- middle wrapper end -->
</div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('#image').change(function(e) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#showImage').attr('src', e.target.result);
            }
            reader.readAsDataURL(e.target.files['0']);
        });
    });

</script>

<script>
    function CopyToClipboard(element) {
        // const copyBtn = document.getElementById('copyBtn')
        const copyText1 = document.getElementById(element)
        copyText1.select();
        copyText1.setSelectionRange(0, 99999); /* For mobile devices */
        document.execCommand('copy'); // Simply copies the selected text to clipboard
        Swal.fire({ //displays a pop up with sweetalert
            toast: true,
            position: 'top-end',
            icon: 'success',
            title: 'Text copied to clipboard',
            showConfirmButton: false,
            timerProgressBar: true,
            timer: 1500
        });
        // const Toast = Swal.mixin({
        //     toast: true,
        //     position: 'top-end',
        //     showConfirmButton: false,
        //     timer: 1500,
        //     timerProgressBar: true,
        // });

        // Toast.fire({
        //     icon: 'success',
        //     title: 'Text copied to clipboard'
        // })
        console.log('Text copied to clipboard');
    }

    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mysipah-lara1\resources\views/admin/admin_profile_view.blade.php ENDPATH**/ ?>