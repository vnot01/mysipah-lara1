<?php $__env->startSection('admin'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-content">

    <nav class="page-breadcrumb">
        <div class="breadcrumb d-flex justify-content-between align-items-center">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Incoming Waste</li>
            </ol>
            <button type="button" class="btn btn-primary btn-icon-text"
                data-bs-toggle="modal" data-bs-target="#modalNewIncoming"
                data-bs-whatever="@getbootstrap">
                <i class="btn-icon-prepend" data-feather="plus"></i>
                New Incoming Waste</button>
                

                <div class="modal fade" id="modalNewIncoming"
                    tabindex="-1" aria-labelledby="modalNewIncomingLabel" aria-hidden="true">
                    
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modalNewIncomingLabel">New Incoming Waste</h5>
                          <button type="button" class="btn-close"
                            data-bs-dismiss="modal" aria-label="btn-close"></button>
                        </div>
                        <form id='addNewIncoming' method="POST" action="<?php echo e(url('/incomingwaste/add')); ?>"
                            class="forms-sample"
                            enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="modal-body">
                                <div class="mb-3" name="nokartu1" id="nokartu1">
                                    <div class="form-group" align="center">
                                        <label>Scan Your RFID Card</label>
                                        <br>
                                        <img src="<?php echo e(url('/upload/rfid.gif')); ?>"
                                            style="height: 100px;width:100px;" >
                                        <br>
                                    </div>
                                </div>
                                <div class="mb-3" name="nokartu" id="nokartu"></div>
                                <div class="mb-3">
                                    <label for="rfid" class="form-label">No. RFID</label>
                                        <input type="text" readonly="true" class="form-control
                                            <?php $__errorArgs = ['rfid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " value="<?php echo e(old('rfid', '')); ?>"
                                            id="rfid" name="rfid" autocomplete="off"
                                            placeholder="Leave Blank If Not Add New">
                                            <?php $__errorArgs = ['rfid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label for="sources-name" class="form-label">Sources Waste</label>
                                    <select class="my-select2 form-select" name="source_id" data-width="100%">
                                        <?php $__empty_1 = true; $__currentLoopData = $listSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item_source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option name="source_id" value="<?php echo e($item_source->id); ?>"><?php echo e($item_source->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="alert alert-danger">
                                            <option value="-1">No Data Available.</option>
                                        </div>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="types-name" class="form-label">Types Waste</label>
                                    <select class="my-select2 form-select" id="type_id"
                                        name="type_id" data-width="100%">
                                        <?php $__empty_1 = true; $__currentLoopData = $listTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item_Types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option name="type_id" value="<?php echo e($item_Types->id); ?>"
                                            data-nama="<?php echo e($item_Types->nama); ?>"><?php echo e($item_Types->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="alert alert-danger">
                                            <option value="-1">No Data Available.</option>
                                        </div>
                                        <?php endif; ?>
                                    </select>
                                    <input name="type_name" id="type_name" type="hidden" class="form-control">
                                </div>
                                <div class="mb-3">
                                    <label for="manufactures-name" class="form-label">Manufactures Waste</label>
                                    <select class="my-select2 form-select" name="manufacture_id" data-width="100%">
                                        <?php $__empty_1 = true; $__currentLoopData = $listManufactures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item_Manufactures): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option name="manufacture_id" value="<?php echo e($item_Manufactures->id); ?>"><?php echo e($item_Manufactures->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="alert alert-danger">
                                            <option value="-1">No Data Available.</option>
                                        </div>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="volume" class="form-label">Volume (kg):</label>
                                    <input name="volume" type="text" class="form-control" id="volume">
                                    
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="row">
      <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            
            <div class="table-responsive">
              <table id="dataTableExample" class="table">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Customer</th>
                    <th>Source</th>
                    <th>Type</th>
                    <th>Manufacture</th>
                    <th>Vol (kg)</th>
                    <th>Last Update</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $listProcessings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr class="align-middle">
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($item->nasabahs->user->name); ?> <br>
                        <?php echo e(Str::mask($item->nasabahs->nokartu, '*',-20, 7)); ?></td>
                    <td><?php echo e($item->sources->nama); ?></td>
                    <td><?php echo e($item->types->nama); ?></td>
                    <td><?php echo e($item->manufactures->nama); ?></td>
                    <td><?php echo e($item->volume); ?></td>
                    <td><?php echo e($item->created_at->format('d-m-Y H:i:s')); ?></td>
                    <td class="text-start">
                        <form onsubmit="return confirm('Are you sure ?');"
                            action="<?php echo e(route('delete.incoming_waste', $item->id)); ?>" method="POST">
                            
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                            <button type="submit" class="btn btn-sm btn-danger fa-regular fa-trash-can"
                                data-toggle="tooltip" title="Delete Incoming Waste!">
                                <i value="<?php echo e($item->id); ?>" class="btn-icon-prepend"></i>
                            </button>
                        </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-danger">
                        No Data Available.
                    </div>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
<script type="text/javascript">
    $(document).ready(function(){
        var self = $(this),
        nokartu = self.data('nokartu');
        id = self.data('id');
        setInterval(function(){
            $.ajax({
                type:"GET",
                url:"/incomingwaste/scan",
                data: {
                    nokartu: nokartu,
                    id: id
                },
                dataType: 'json',
                success:function(data)
                {
                    $('#rfid').val(data.nokartu);
                }
            });
        },1000);

        $('#type_id').on('change',function(){
            var typeName = $(this).children('option:selected').data('nama');
            $('#type_name').val(typeName);
        });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mysipah-lara1\resources\views/main/incomingwaste/index.blade.php ENDPATH**/ ?>