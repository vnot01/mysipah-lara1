<?php $__env->startSection('admin'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">
    <nav class="page-breadcrumb">
        <div class="breadcrumb d-flex justify-content-between align-items-center">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Lists of Sources</li>
            </ol>
            <button type="button" class="btn btn-primary btn-icon-text"
                data-bs-toggle="modal" data-bs-target="#modalNewIncoming"
                data-bs-whatever="@getbootstrap">
                <i class="btn-icon-prepend" data-feather="plus"></i>
                Create Sources</button>

                <div class="modal fade" id="modalNewIncoming"
                    tabindex="-1" aria-labelledby="modalNewIncomingLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modalNewIncomingLabel">Add New Sources</h5>
                          <button type="button" class="btn-close"
                            data-bs-dismiss="modal" aria-label="btn-close"></button>
                        </div>
                        <form method="POST" action="<?php echo e(url('/all/sources/add')); ?>"
                            class="forms-sample"
                            enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="modal-body">
                                <div class="mb-3">
                                    <label for="source_name" class="form-label">Source Name</label>
                                    <input type="text" class="form-control
                                        <?php $__errorArgs = ['source_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " value="<?php echo e(old('source_name', '')); ?>"
                                        id="source_name" name="source_name" autocomplete="off"
                                        placeholder="Leave Blank If Not Add New">
                                    <?php $__errorArgs = ['source_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Modal Update Barang-->

<!-- End Modal UPDATE Barang-->
<div class="modal fade" id="modalEditSources"
tabindex="-1" aria-labelledby="modalEditSourcesLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalEditSourcesLabel">Edit Sources</h5>
                    <button type="button" class="btn-close"
                        data-bs-dismiss="modal" aria-label="btn-close"></button>
            </div>
            <form method="POST" action="<?php echo e(url('/all/sources/edit')); ?>" class="forms-sample"
                enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php echo method_field('put'); ?>
            <input type="hidden" class="form-control" id="source_id" name="source_id">
            <div class="modal-body">
                <div class="mb-3">
                    <label for="edit_source_name" class="form-label">Source Name</label>
                    
                    <input type="text" class="form-control <?php $__errorArgs = ['edit_source_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " id="edit_source_name"
                    name="edit_source_name" placeholder="Enter Source Name" value="" required>
                    <?php $__errorArgs = ['edit_source_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </div>
            </form>
        </div>
    </div>
</div>

    <div class="row">
      <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <div class="table-responsive">
              <table id="dataTableExample" class="table">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Sources</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $listSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr class="align-middle">
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($item->nama); ?></td>
                    <td class="text-start">
                        <form onsubmit="return confirm('Are you sure ?');"
                            action="<?php echo e(route('delete.sources', $item->id)); ?>" method="POST">
                        
                            <a href="javascript:void(0)" data-toggle="tooltip"
                                data-id="<?php echo e($item->id); ?>" data-original-title="Edit"
                                class="btn btn-primary btn-sm editPost fa-regular fa-pen-to-square"></a>
                        
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        
                        
                            <button type="submit" class="btn btn-sm btn-danger fa-regular fa-trash-can">
                                <i value="<?php echo e($item->id); ?>" class="btn-icon-prepend"></i>
                            </button>
                        </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-danger">
                        No Data Available.
                    </div>
                  <?php endif; ?>
                </tbody>
              </table>
              
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>

  
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript">
    //button create source event
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('body').on('click', '.editPost', function () {
        var source_id = $(this).data('id');
        //fetch detail source with ajax
        // alert(source_id);
        // $('#modalEditSources').modal('show');

        $.ajax({
            url: `/all/sources/edit/${source_id}`,
            type: "GET",
            cache: false,
            success:function(response){
                //fill data to form
                console.log(response.data.nama);
                console.log(response);
                //open modal
                $('#source_id').val(response.data.id);
                $('#edit_source_name').val(response.data.nama);
                $('#savedata').val("edit-user");
                // $('#id').val(response.data.id);
                // $('#name').val(response.data.name);
                $('#modalEditSources').modal('show');
            }
        });
    });

    // //action update source
    // $('#update').click(function(e) {
    //     e.preventDefault();
    //     //define variable
    //     let source_id = $('#source_id').val();
    //     let nama   = $('#name-edit').val();
    //     let token   = $("meta[name='csrf-token']").attr("content");
    //     //ajax
    //     $.ajax({

    //         url: `/edit/sources/${source_id}`,
    //         type: "PUT",
    //         cache: false,
    //         data: {
    //             "nama": title,
    //             "content": content,
    //             "_token": token
    //         },
    //         success:function(response){

    //             //show success message
    //             Swal.fire({
    //                 type: 'success',
    //                 icon: 'success',
    //                 title: `${response.message}`,
    //                 showConfirmButton: false,
    //                 timer: 3000
    //             });

    //             //data source
    //             let source = `
    //                 <tr id="index_${response.data.id}">
    //                     <td>${response.data.nama}</td>
    //                     <td class="text-center">
    //                         <a href="javascript:void(0)" id="btn-edit-source"
    //                             data-id="${response.data.id}" class="btn btn-primary btn-sm">EDIT</a>
    //                         <a href="javascript:void(0)" id="btn-delete-source"
    //                             data-id="${response.data.id}" class="btn btn-danger btn-sm">DELETE</a>
    //                     </td>
    //                 </tr>
    //             `;
    //             //append to source data
    //             $(`#index_${response.data.id}`).replaceWith(source);
    //             //close modal
    //             $('#modal-edit').modal('hide');

    //         },
    //         error:function(error){
    //             if(error.responseJSON.title[0]) {
    //                 //show alert
    //                 $('#alert-title-edit').removeClass('d-none');
    //                 $('#alert-title-edit').addClass('d-block');
    //                 //add message to alert
    //                 $('#alert-title-edit').html(error.responseJSON.title[0]);
    //             }

    //             if(error.responseJSON.content[0]) {
    //                 //show alert
    //                 $('#alert-content-edit').removeClass('d-none');
    //                 $('#alert-content-edit').addClass('d-block');
    //                 //add message to alert
    //                 $('#alert-content-edit').html(error.responseJSON.content[0]);
    //             }
    //         }
    //     });
    // });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mysipah-lara1\resources\views/main/mastersources/index.blade.php ENDPATH**/ ?>