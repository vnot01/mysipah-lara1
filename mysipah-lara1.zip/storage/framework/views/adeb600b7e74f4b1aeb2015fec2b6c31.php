<nav class="sidebar">
    <div class="sidebar-header">
      <a href="#" class="sidebar-brand">
        My<span>SIPAH</span>
      </a>
      <div class="sidebar-toggler not-active">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
    <div class="sidebar-body">
      <ul class="nav">
        <li class="nav-item nav-category">Main</li>
        <li class="nav-item">
          <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link">
            <i class="link-icon" data-feather="box"></i>
            <span class="link-title">Dashboard</span>
          </a>
        </li>

        <li class="nav-item nav-category">Main</li>
        <li class="nav-item">
          <a href="<?php echo e(route('main.incoming_waste')); ?>" class="nav-link">
            <i class="link-icon" data-feather="message-square"></i>
            <span class="link-title">Incoming Waste</span>
          </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#waste_processing" role="button" aria-expanded="false" aria-controls="waste_processing">
              <i class="link-icon" data-feather="clock"></i>
              <span class="link-title">Waste Processing</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="waste_processing">
              <ul class="nav sub-menu">
                <li class="nav-item">
                  <a href="pages/email/read.html" class="nav-link">Lists Queue Processing</a>
                </li>
                <li class="nav-item">
                  <a href="pages/email/inbox.html" class="nav-link">Lists Processing</a>
                </li>
                
              </ul>
            </div>
        </li>
        <li class="nav-item">
            <a href="pages/apps/chat.html" class="nav-link">
              <i class="link-icon" data-feather="truck"></i>
              <span class="link-title">Inventory</span>
            </a>
        </li>
        
        <li class="nav-item">
            <a href="<?php echo e(route('nasabah.index')); ?>" class="nav-link">
              <i class="link-icon" data-feather="users"></i>
              <span class="link-title">Nasabah</span>
            </a>
          </li>

        <li class="nav-item nav-category">Master</li>
        <li class="nav-item">
          <a class="nav-link" data-bs-toggle="collapse" href="#sources"
            role="button" aria-expanded="false" aria-controls="sources">
            <i class="link-icon" data-feather="database"></i>
            <span class="link-title">Sources</span>
            <i class="link-arrow" data-feather="chevron-down"></i>
          </a>
          <div class="collapse" id="sources">
            <ul class="nav sub-menu">
                <li class="nav-item" id="all_sources">
                    <a href="<?php echo e(route('all.sources')); ?>" class="nav-link">All Sources</a>
                </li>
                <li class="nav-item" id="new_sources">
                  <a href="<?php echo e(route('new.sources')); ?>" class="nav-link">Create Sources</a>
                </li>
            </ul>
          </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#types" role="button" aria-expanded="false" aria-controls="types">
              <i class="link-icon" data-feather="database"></i>
              <span class="link-title">Types</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="types">
              <ul class="nav sub-menu">
                <li class="nav-item">
                    <a href="<?php echo e(route('all.types')); ?>" class="nav-link">All Types</a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('new.types')); ?>" class="nav-link">Create Types</a>
                </li>
              </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#manufactures" role="button" aria-expanded="false" aria-controls="manufactures">
              <i class="link-icon" data-feather="database"></i>
              <span class="link-title">Manufactures</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="manufactures">
              <ul class="nav sub-menu">
                <li class="nav-item">
                    <a href="<?php echo e(route('all.manufactures')); ?>" class="nav-link">All Manufactures</a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('new.manufactures')); ?>" class="nav-link">Create Manufactures</a>
                </li>
              </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#products" role="button" aria-expanded="false" aria-controls="products">
              <i class="link-icon" data-feather="database"></i>
              <span class="link-title">Products</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="products">
              <ul class="nav sub-menu">
                <li class="nav-item">
                    <a href="<?php echo e(route('all.products')); ?>" class="nav-link">All Products</a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('new.products')); ?>" class="nav-link">Create Products</a>
                </li>
              </ul>
            </div>
        </li>

        

        

        
      </ul>
    </div>
  </nav>
<?php /**PATH C:\laragon\www\mysipah-lara1\resources\views/admin/nav/sidebar.blade.php ENDPATH**/ ?>